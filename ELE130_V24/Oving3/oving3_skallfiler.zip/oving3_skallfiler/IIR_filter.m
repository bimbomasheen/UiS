function[FilteredValue] = IIR_filter(OldFilteredValue,Measurement,Parameter)

% fyll inn

end