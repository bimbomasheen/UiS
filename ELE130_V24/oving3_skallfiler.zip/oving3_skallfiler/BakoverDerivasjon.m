function Sekant = BakoverDerivasjon(FunctionValues, Timestep)

% fyll inn

end
