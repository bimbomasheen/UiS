function IntValueNew = EulersForover(IntValueOld, Timestep, FunctionValue)

% fyll inn

end
