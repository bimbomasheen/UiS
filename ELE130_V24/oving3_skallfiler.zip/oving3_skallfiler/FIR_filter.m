function[FilteredValue] = FIR_filter(Measurement,NoMeas)

% juster på NoOfMeas
% fyll inn filterkode

end 

